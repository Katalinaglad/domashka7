<?php
$directory = __DIR__;
if (isset($_POST['rename'])) {
    $oldName = $directory . '/' . $_POST['old_name'];
    $newName = $directory . '/' . $_POST['new_name'];
    if (file_exists($oldName) && !empty($_POST['new_name'])) {
        rename($oldName, $newName);
        echo "Файл успешно переименован!<br>";
    } else {
        echo "Ошибка при переименовании файла.<br>";
    }
}

if (isset($_POST['delete'])) {
    $fileToDelete = $directory . '/' . $_POST['file_name'];
    if (file_exists($fileToDelete)) {
        unlink($fileToDelete);
        echo "Файл успешно удалён!<br>";
    } else {
        echo "Ошибка при удалении файла.<br>";
    }
}

$files = array_filter(scandir($directory), function ($file) use ($directory) {
    return is_file($directory . '/' . $file) && preg_match('/\.(jpg|jpeg|png|gif)$/i', $file);
});
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Файлы папки</title>
</head>
<body>
    <h1>Содержимое папки</h1>

    <?php if (empty($files)): ?>
        <p>В папке нет изображений.</p>
    <?php else: ?>
        <ul>
            <?php foreach ($files as $file): ?>
                <li>
                    <img src="<?= htmlspecialchars($file) ?>" alt="<?= htmlspecialchars($file) ?>" style="width:100px; height:auto;"><br>
                    <strong><?= htmlspecialchars($file) ?></strong>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="file_name" value="<?= htmlspecialchars($file) ?>">
                        <button type="submit" name="delete">Удалить</button>
                    </form>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="old_name" value="<?= htmlspecialchars($file) ?>">
                        <input type="text" name="new_name" placeholder="Новое имя">
                        <button type="submit" name="rename">Переименовать</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</body>
</html>
