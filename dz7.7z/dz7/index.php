<?php
// Получаем путь к текущей директории, в которой находится скрипт
$directory = __DIR__;

// Проверяем, была ли отправлена форма на переименование файла
if (isset($_POST['rename'])) {
    // Формируем полный путь к старому и новому имени файла
    $oldName = $directory . '/' . $_POST['old_name'];
    $newName = $directory . '/' . $_POST['new_name'];

    // Проверяем, существует ли файл и введено ли новое имя
    if (file_exists($oldName) && !empty($_POST['new_name'])) {
        // Переименовываем файл
        rename($oldName, $newName);
        echo "Файл успешно переименован!<br>";
    } else {
        echo "Ошибка при переименовании файла.<br>";
    }
}

// Проверяем, была ли отправлена форма на удаление файла
if (isset($_POST['delete'])) {
    // Формируем полный путь к удаляемому файлу
    $fileToDelete = $directory . '/' . $_POST['file_name'];

    // Проверяем, существует ли файл
    if (file_exists($fileToDelete)) {
        // Удаляем файл
        unlink($fileToDelete);
        echo "Файл успешно удалён!<br>";
    } else {
        echo "Ошибка при удалении файла.<br>";
    }
}

// Получаем список всех изображений в текущей папке (фильтруем только файлы изображений)
$files = array_filter(scandir($directory), function ($file) use ($directory) {
    // Проверяем, является ли элемент файлом и соответствует ли он одному из расширений изображений
    return is_file($directory . '/' . $file) && preg_match('/\.(jpg|jpeg|png|gif)$/i', $file);
});
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Файлы папки</title>
</head>
<body>
    <h1>Содержимое папки</h1>

    <!-- Если в папке нет изображений, показываем сообщение -->
    <?php if (empty($files)): ?>
        <p>В папке нет изображений.</p>
    <?php else: ?>
        <ul>
            <!-- Выводим список изображений -->
            <?php foreach ($files as $file): ?>
                <li>
                    <!-- Отображаем изображение -->
                    <img src="<?= htmlspecialchars($file) ?>" alt="<?= htmlspecialchars($file) ?>" style="width:100px; height:auto;"><br>
                    <strong><?= htmlspecialchars($file) ?></strong>

                    <!-- Форма для удаления файла -->
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="file_name" value="<?= htmlspecialchars($file) ?>">
                        <button type="submit" name="delete">Удалить</button>
                    </form>

                    <!-- Форма для переименования файла -->
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="old_name" value="<?= htmlspecialchars($file) ?>">
                        <input type="text" name="new_name" placeholder="Новое имя">
                        <button type="submit" name="rename">Переименовать</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</body>
</html>
